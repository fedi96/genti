<?php
include 'config.php';
if(isset($_POST['lang'])){
    $lang = $_POST["lang"];
    $genre = $_POST["genre"];
    $description = $_POST["description"];
    $actor = $_POST["actor"];
    $released = $_POST["released"];
    $rate = $_POST["rate"];
    $cover = $_POST["cover"];
    $trailer = $_POST["trailer"];
    $title = $_POST["title"];
    $sql = "INSERT INTO movies(lang,genre,description,actor,released,cover,trailer,title,rate) VALUES('$lang','$genre','$description','$actor','$released','$cover','$trailer','$title','$rate')";
    $stmt = $conn->prepare($sql);
    $stmt->execute(array($lang,$genre,$description,$actor,$released,$cover,$trailer,$title,$rate));
  }
?>
