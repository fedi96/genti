<?php
include 'config.php';
if(isset($_POST['src'])){
    $src = $_POST["src"];
    $lang = $_POST["lang"];
    $movie = $_POST["movie"];
    $quality = $_POST["quality"];
    $sql = "INSERT INTO subtitles(src,lang,movie) VALUES('$src','$lang','$movie')";
    $stmt = $conn->prepare($sql);
    $stmt->execute(array($src,$lang,$movie));
  }
?>
