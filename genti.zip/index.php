<?php
include 'config.php';
$id =$_GET['id'];
$stm = $conn;
$stm1 = $conn;
$stm2 = $conn;
$sql = 'SELECT * FROM movies WHERE rate > 2';
?>

<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/main.css" />
    <link rel="stylesheet" href="css/icons.css" />
    <link rel="stylesheet" href="css/exp.css" />
    <link href="css/cir.css" rel="stylesheet" />
    <script src="js/angular.min.js"></script>
    <link rel="stylesheet" href="css/animate.css">
    <link rel="stylesheet" href="css/font-awesome.css"/>
    <title>Genti</title>
        <!-- Description and Keywords (start) -->
        <meta content='YOUR DESCRIPTION HERE' name='description'/>
        <meta content='YOUR KEYWORDS HERE' name='keywords'/>
        <!-- Description and Keywords (end) -->
        <meta content='' property='og:site_name'/>
        <meta content='' name='twitter:domain'/>
        <meta content='' name='twitter:title'/>
        <meta content='summary' name='twitter:card'/>
        <meta content='' name='twitter:title'/>
        <!-- Social Media meta tag need customer customization -->
        <meta content='Facebook App ID here' property='fb:app_id'/>
        <meta content='Facebook Admin ID here' property='fb:admins'/>
        <meta content='@username' name='twitter:site'/>
        <meta content='@username' name='twitter:creator'/>
        <script>
        function rate(n) {
          var i=0;
          t="";
        for(i;i<n;i++){
            var t = t + '<svg style="width:24px;height:24px" viewBox="0 0 24 24"><path fill="#000000" d="M12,17.27L18.18,21L16.54,13.97L22,9.24L14.81,8.62L12,2L9.19,8.62L2,9.24L7.45,13.97L5.82,21L12,17.27Z" /></svg>';
            }
            document.write(t);
        }
        </script>
</head>

<body ng-app="Portfolio" class="fain">
    <div class="columns filternav" id="nav">
        <div class="column col-9 col-mx-auto">
            <header class="navbar">
                <section class="navbar-section">
                    <h2>Genti</h2>
                </section>
                <section class="navbar-center">
                  <a href="#" class="btn">Home</a>
                  <a href="#" class="btn">Movies</a>
                  <a href="#" class="btn">Series</a>
                </section>
                <section class="navbar-section">
                  <div class="input-group input-inline">
                    <input class="form-input" type="text" placeholder="search">
                    <button class="btn btn-primary input-group-btn">Search</button>
                  </div>
                </section>
            </header>
        </div>
    </div>
    <div class="columns" ng-controller="MainController">
        <div class="column col-11 col-9-lms col-mx-auto">
            <div class="container">
                <div class="columns">
                    <div class="column col">
                        <div class="fain" id="tag-1">
                            <div class="columns">
                                <div class="column col-12-xlms col-12-lms portfolio col-12 parallax">
                                  <div class="parallax-top-left" tabindex="1"></div>
                                  <div class="parallax-top-right" tabindex="2"></div>
                                  <div class="parallax-bottom-left" tabindex="3"></div>
                                  <div class="parallax-bottom-right" tabindex="4"></div>
                                  <div class="parallax-content">
                                  <div class="parallax-front">
                                    <h2>Home Of Movies</h2>

                                  </div>
                                  <div class="parallax-back">
                                    <img src="img/the_dark_knight_movie.jpg" style="width:100%" class="img-responsive rounded" ...>
                                  </div>
                                </div>
                                </div>

<?php
foreach ($stm->query($sql) as $row) {
?>
                                <div class="column col-3-xlms col-3-xl col-4-lg col-4-md col-6-sm col-6-xs portfolio">
                                            <div class="card">
                                              <div class="parallax">
                                                <div class="parallax-content">
                                                  <div class="parallax-front" style="background: #272b32bf;">
                                                    <div class="card-title h5"><?php echo $row['title'];?></div>
                                                  </div>
                                                  <div class="parallax-back">
                                                    <img src="img/im.jpg" style="width:100%" class="img-responsive rounded" ...>
                                                  </div>
                                                  </div>
                                              </div>
                                              <div class="card-header">
                                                <a href="watch.php?id=<?php echo $row['id'];?>" class="btn btn-primary float-right">
                                                  <svg style="width:24px;height:24px" viewBox="0 0 24 24">
                                                      <path fill="#000000" d="M18,4L20,8H17L15,4H13L15,8H12L10,4H8L10,8H7L5,4H4A2,2 0 0,0 2,6V18A2,2 0 0,0 4,20H20A2,2 0 0,0 22,18V4H18Z" />
                                                  </svg>
                                                </a>
                                                <div class="card-subtitle text-gray"><script>rate(<?php echo $row['rate'];?>);</script></div>
                                              </div>
                                              <div class="card-body">
                                                <?php echo $row['description'];?>
                                              </div>
                                            </div>
                                </div>
                                <?php
                              }
                                ?>

                            </div>

                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="columns footer">
        <div class="column col-9 col-mx-auto">
            <div>
                copyright &copy; <a href="#">Genti</a> 2018
            </div>
        </div>
    </div>

        <script src="js/app.js"></script>
        <script src="js/main.js"></script>
        <script src="js/jquery.min.js"></script>
        <script id='typist' language='javascript' type='text/javascript'>//<![CDATA[
              // Generated by CoffeeScript 1.8.0
              (function() {
                var Utilities,
                  __bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
                  __hasProp = {}.hasOwnProperty,
                  __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

                Utilities = (function() {
                  function Utilities() {
                    this._fireEvent = __bind(this._fireEvent, this);
                    this._empty = __bind(this._empty, this);
                    this._each = __bind(this._each, this);
                  }

                  Utilities.prototype._addEvent = function(element, event, fn, useCapture) {
                    if (useCapture == null) {
                      useCapture = false;
                    }
                    return element.addEventListener(event, fn, useCapture);
                  };

                  Utilities.prototype._forEach = function(array, fn, bind) {
                    var i, l, _results;
                    i = 0;
                    l = array.length;
                    _results = [];
                    while (i < l) {
                      if (i in array) {
                        fn.call(bind, array[i], i, array);
                      }
                      _results.push(i++);
                    }
                    return _results;
                  };

                  Utilities.prototype._each = function(array, fn, bind) {
                    if (array) {
                      this._forEach(array, fn, bind);
                      return array;
                    }
                  };

                  Utilities.prototype._pass = function(fn, args, bind) {
                    if (args == null) {
                      args = [];
                    }
                    return function() {
                      return fn.apply(bind, args);
                    };
                  };

                  Utilities.prototype._delay = function(fn, delay, bind, args) {
                    if (args == null) {
                      args = [];
                    }
                    return setTimeout(this._pass(fn, args, bind), delay);
                  };

                  Utilities.prototype._periodical = function(fn, periodical, bind, args) {
                    if (args == null) {
                      args = [];
                    }
                    return setInterval(this._pass(fn, args, bind), periodical);
                  };

                  Utilities.prototype._setHtml = function(element, string) {
                    return element.innerHTML = string;
                  };

                  Utilities.prototype._getHtml = function(element) {
                    return element.innerHTML;
                  };

                  Utilities.prototype._empty = function(element) {
                    return this._setHtml(element, "");
                  };

                  Utilities.prototype._fireEvent = function(event, text) {
                    if (this.options[event]) {
                      return this.options[event].call(this, text, this.options);
                    }
                  };

                  Utilities.prototype._extend = function(object, properties) {
                    var key, val;
                    for (key in properties) {
                      val = properties[key];
                      object[key] = val;
                    }
                    return object;
                  };

                  return Utilities;

                })();

                this.Typist = (function(_super) {
                  __extends(Typist, _super);

                  function Typist(element, options) {
                    if (options == null) {
                      options = {};
                    }
                    this.typeLetter = __bind(this.typeLetter, this);
                    this.typeLetters = __bind(this.typeLetters, this);
                    this.typeText = __bind(this.typeText, this);
                    this.selectOffset = __bind(this.selectOffset, this);
                    this.selectText = __bind(this.selectText, this);
                    this.fetchVariations = __bind(this.fetchVariations, this);
                    this.next = __bind(this.next, this);
                    this.slide = __bind(this.slide, this);
                    this.setupDefaults = __bind(this.setupDefaults, this);
                    this.options = {
                      typist: element,
                      letterSelectInterval: 60,
                      interval: 3000,
                      selectClassName: "selectedText"
                    };
                    this.options = this._extend(this.options, options);
                    this.elements = {
                      typist: this.options.typist
                    };
                    this.offsets = {
                      current: {
                        index: 0,
                        text: ""
                      }
                    };
                    if (this.elements.typist) {
                      this.setupDefaults();
                    }
                  }

                  Typist.prototype.setupDefaults = function() {
                    this.variations = this.fetchVariations(this.elements.typist);
                    this.newText = [];
                    return this.timer = this._periodical(this.slide, this.options.interval);
                  };

                  Typist.prototype.slide = function(forcedText) {
                    this.offsets.current.text = this.variations[this.offsets.current.index];
                    this.offsets.current.text = this.offsets.current.text.split("");
                    this._each(this.offsets.current.text, this.selectText);
                    this.offsets.current.index = this.next(this.offsets.current.index);
                    this._delay((function(_this) {
                      return function() {
                        _this.options.currentSlideIndex = _this.offsets.current.index;
                        return _this.typeText(_this.variations[_this.offsets.current.index]);
                      };
                    })(this), this.options.letterSelectInterval * this.offsets.current.text.length);
                    if (this.variations.length <= this.offsets.current.index) {
                      this.offsets.current.index = 0;
                    } else if (this.offsets.current.index === 0) {
                      this.offsets.current.index = this.variations.length;
                    } else {
                      this.offsets.current.index = this.offsets.current.index;
                    }
                    return this.newText.length = 0;
                  };

                  Typist.prototype.next = function(offset) {
                    return offset = offset + 1;
                  };

                  Typist.prototype.fetchVariations = function(element) {
                    var text, value, variations;
                    text = element.getAttribute("data-typist");
                    value = this._getHtml(element);
                    variations = text.split(",");
                    variations.splice(0, 0, value);
                    return variations;
                  };

                  Typist.prototype.selectText = function(letter, index) {
                    return this._delay((function(_this) {
                      return function() {
                        return _this.selectOffset((_this.offsets.current.text.length - index) - 1);
                      };
                    })(this), index * this.options.letterSelectInterval);
                  };

                  Typist.prototype.selectOffset = function(offset) {
                    var selected, text, unselected;
                    text = this.offsets.current.text;
                    selected = text.slice(offset, text.length);
                    selected = selected.join("");
                    unselected = text.slice(0, offset);
                    unselected = unselected.join("");
                    return this._setHtml(this.elements.typist, "" + unselected + "<em class=\"" + this.options.selectClassName + "\">" + selected + "</em>");
                  };

                  Typist.prototype.typeText = function(text) {
                    this.typeTextSplit = text.split("");
                    this._each(this.typeTextSplit, this.typeLetters);
                    return this._fireEvent("onSlide", text);
                  };

                  Typist.prototype.typeLetters = function(letter, index) {
                    clearInterval(this.timer);
                    return this._delay((function(_this) {
                      return function() {
                        return _this.typeLetter(letter, index);
                      };
                    })(this), index * this.options.letterSelectInterval);
                  };

                  Typist.prototype.typeLetter = function(letter, index) {
                    this._empty(this.elements.typist);
                    this.newText.push(letter);
                    this._setHtml(this.elements.typist, this.newText.join(""));
                    if (this.typeTextSplit.length === index + 1) {
                      return this.timer = this._periodical(this.slide, this.options.interval);
                    }
                  };

                  return Typist;

                })(Utilities);

              }).call(this);
              //]]>
        </script>
        <script>
            window.addEventListener("load", function() {
                function n() {
                    var a = document.createElement("style");
                    a.type = "text/css";
                    a.styleSheet ? a.styleSheet.cssText = '/*rippleJS*/.rippleJS,.rippleJS.fill::after{top:0;left:0;right:0;bottom:0}.rippleJS{display:block;overflow:hidden;border-radius:inherit;-webkit-mask-image:-webkit-radial-gradient(circle,#fff,#000)}.rippleJS.fill::after{content:""}.rippleJS.fill{border-radius:1000000px}.rippleJS .ripple{position:absolute;border-radius:100%;background:currentColor;opacity:.2;width:0;height:0;-webkit-transition:-webkit-transform .4s ease-out,opacity .4s ease-out;transition:transform .4s ease-out,opacity .4s ease-out;-webkit-transform:scale(0);transform:scale(0);pointer-events:none;-webkit-touch-callout:none;-webkit-user-select:none;-khtml-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none}.rippleJS .ripple.held{opacity:.4;-webkit-transform:scale(1);transform:scale(1)}.rippleJS .ripple.done{opacity:0}' :
                        a.appendChild(document.createTextNode('/*rippleJS*/.rippleJS,.rippleJS.fill::after{top:0;left:0;right:0;bottom:0}.rippleJS{display:block;overflow:hidden;border-radius:inherit;-webkit-mask-image:-webkit-radial-gradient(circle,#fff,#000)}.rippleJS.fill::after{content:""}.rippleJS.fill{border-radius:1000000px}.rippleJS .ripple{position:absolute;border-radius:100%;background:currentColor;opacity:.2;width:0;height:0;-webkit-transition:-webkit-transform .4s ease-out,opacity .4s ease-out;transition:transform .4s ease-out,opacity .4s ease-out;-webkit-transform:scale(0);transform:scale(0);pointer-events:none;-webkit-touch-callout:none;-webkit-user-select:none;-khtml-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none}.rippleJS .ripple.held{opacity:.4;-webkit-transform:scale(1);transform:scale(1)}.rippleJS .ripple.done{opacity:0}'));
                    document.body.appendChild(a)
                }

                function g(a, c) {
                    var e = c.target,
                        g = e.classList;
                    if (g.contains("rippleJS")) {
                        var f = e.getAttribute("data-event");
                        if (!f || f == a) {
                            e.setAttribute("data-event", a);
                            var b = e.getBoundingClientRect(),
                                f = c.offsetX,
                                h;
                            void 0 !== f ? h = c.offsetY : (f = c.clientX - b.left, h = c.clientY - b.top);
                            var d = document.createElement("div"),
                                b = b.width == b.height ? 1.412 * b.width : Math.sqrt(b.width * b.width + b.height * b.height),
                                k = 2 * b + "px";
                            d.style.width = k;
                            d.style.height = k;
                            d.style.marginLeft = -b + f + "px";
                            d.style.marginTop = -b + h + "px";
                            d.className = "ripple";
                            e.appendChild(d);
                            window.setTimeout(function() {
                                d.classList.add("held")
                            }, 0);
                            var l = "mousedown" == a ? "mouseup" : "touchend",
                                m = function() {
                                    document.removeEventListener(l, m);
                                    d.classList.add("done");
                                    window.setTimeout(function() {
                                        e.removeChild(d);
                                        e.children.length || (g.remove("active"), e.removeAttribute("data-event"))
                                    }, 650)
                                };
                            document.addEventListener(l, m)
                        }
                    }
                }(function() {
                    var a = document.createElement("div");
                    a.className = "rippleJS";
                    document.body.appendChild(a);
                    var c = "absolute" == window.getComputedStyle(a).position;
                    document.body.removeChild(a);
                    return c
                })() || n();
                document.addEventListener("mousedown", function(a) {
                    0 == a.button && g(a.type, a)
                });
                document.addEventListener("touchstart", function(a) {
                    for (var c = 0; c < a.changedTouches.length; ++c) g(a.type, a.changedTouches[c])
                })
            });
            var $contactform = $('#contactform'),
                $success = 'Your message has been sent. Thank you!';
            $contactform.submit(function() {
                $.ajax({
                    type: "POST",
                    url: "contact.php",
                    data: $(this).serialize(),
                    success: function(msg) {
                        if (msg == 'SEND') {
                            response = '<div class="toast toast-success">' + $success + '</div>';
                        } else {
                            response = '<div class="toast toast-warning">' + msg + '</div>';
                        }
                        $(".toast").remove();
                        $contactform.prepend(response);
                    }
                });
                return false;
            });
        </script>
        <script language='javascript' type='text/javascript'>
         (function () {
          var typist;
          typist = document.querySelector('#typist-element');
          new Typist(typist, {
                letterInterval: 60,
                textInterval: 3000
              });
            }.call(this));
          </script>
          <script>
          $(document).ready(function(){
            $(".scrl").on('click', function(event) {
              if (this.hash !== "") {
                event.preventDefault();
                var hash = this.hash;
                $('html, body').animate({
                  scrollTop: $(hash).offset().top
                }, 800, function(){
                  window.location.hash = hash;
                });
              }
            });
          });
        </script>
</body>

</html>
