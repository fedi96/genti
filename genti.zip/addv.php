<?php
include 'config.php';
if(isset($_POST['src'])){
    $src = $_POST["src"];
    $type = $_POST["type"];
    $link = $_POST["link"];
    $movie = $_POST["movie"];
    $quality = $_POST["quality"];
    $sql = "INSERT INTO videos(src,type,link,movie,quality) VALUES('$src','$type','$link','$movie','$quality')";
    $stmt = $conn->prepare($sql);
    $stmt->execute(array($src,$type,$link,$movie,$quality));
  }
?>
